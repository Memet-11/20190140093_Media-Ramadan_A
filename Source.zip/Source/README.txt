README FILE FOR THE SOURCE CODE
*** Beginning HTML: Modern Guide and Reference ***

The source code zip file contains all the source code in the book. You can unzip 
it to any directory. When unzipped, the source code is organized in folders 
by chapter, there is a separate folder for each chapter. 

Have fun playing with the examples...

 - David Schultz & Craig Cook